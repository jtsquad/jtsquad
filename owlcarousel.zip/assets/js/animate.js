var typed = new Typed('#alternation', {
    strings: ['Inovação', 'Criatividade', 'Qualidade', 'JT Squad'],
    typeSpeed: 30,
    backSpeed: 30,
    backDelay: 1000,
    startDelay: 2000,
    loop: true
});     